#' @name variable.sites
#' @export variable.sites
#' 
#' @title Variable Sites Among Sequences
#'  
#' @param dna.seq consensus sequence or list of DNA sequences.
#' @param bases character vector of bases to consider.
#' 
#' @author Eric Archer \email{eric.archer@@noaa.gov}
#' 
#' @seealso \link{fixed.sites}

variable.sites <- function(dna.seq, bases = c("a", "c", "g", "t", "-")) {
  stopifnot.aligned(dna.seq)
  
  site.freqs <- base.freqs(dna.seq, bases)$site.freqs
  var.site <- apply(site.freqs, 2, function(site) sum(site > 0) > 1)
  var.seqs <- lapply(dna.seq, function(x) tolower(x[var.site]))
  var.site.freqs <- as.matrix(site.freqs[, var.site], nrow = nrow(site.freqs))
  colnames(var.site.freqs) <- which(var.site)
  list(sites = var.seqs, site.freqs = var.site.freqs)
}