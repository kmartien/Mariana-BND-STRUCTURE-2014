#' @rdname label.haplotypes
#' @usage \method{label.haplotypes}{gtypes}(x, ...)

label.haplotypes.gtypes <- function(x, ...) {
  stopifnot.gtypes(x, "haploid")
  opt <- options(stringsAsFactors = FALSE) 
  
  # label haplotypes
  desc <- attr(x, "description")
  x <- decode(x)
  new.haps <- label.haplotypes(x$sequences, ...)
  
  # reassign haplotypes
  gen.mat <- cbind(id = rownames(x$genotypes), strata = x$genotypes[, "strata"])
  gen.mat <- cbind(gen.mat, haplotype = new.haps$haps[x$genotypes[, 2]])
  
  options(opt)
  gtypes(gen.mat, dna.seq = new.haps$hap.seqs, description = desc)
}
