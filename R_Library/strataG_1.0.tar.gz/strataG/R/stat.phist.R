#' @name stat.phist
#' @export stat.phist
#' @importFrom ape dist.dna
#' @importFrom ape as.DNAbin
#' 
#' @title PHIst Analysis of Population Structure
#' 
#' @param g a \code{gtypes} object
#' @param hap.dist a matrix of pairwise haplotype distances
#' @param model a character string specifying the evolutionary model to be used. See \link{dist.dna} in the \code{ape} package. 
#' @param pairwise.deletion a logical indicating whether to delete the sites with missing data in a pairwise way. See \link{dist.dna} in the \code{ape} package.
#' 
#' @references Excoffier, L., Smouse, P.E., and J.M. Quattro. 1992. Analysis of molecular variance inferred from metric distances among DNA haplotypes: 
#' Application to human mitochondrial DNA restriction data 
#' 
#' @author Eric Archer \email{eric.archer@@noaa.gov}
#' 
#' @examples
#' data(dolph.strata)
#' data(dolph.haps)
#' mtdna <- gtypes(dolph.strata, id.col = 1, strata.col = 2, locus.col = 4, dna.seq = dolph.haps)
#' 
#' stat.phist(mtdna)

stat.phist <- function(g, hap.dist = NULL, model = "N", pairwise.deletion = T)  {
  g <- check.gtypes(g, "haploid")
  
  stat.name <- "PHIst"
  if(!is.null(hap.dist)) {
    if(!("dist" %in% class(hap.dist))) stop("'hap.dist' must be of class 'dist'")
    if(!all(decode.loci(g) %in% labels(hap.dist))) stop("Some haplotypes in 'g' could not be found in 'hap.dist'")
    if(all(hap.dist[lower.tri(hap.dist)] == 1)) stat.name <- "Fst"
  } else if(is.null(g$sequences)) {
    haps <- unique(g$genotypes[, 2])
    hap.dist <- matrix(1, nrow = length(haps), ncol = length(haps), dimnames = list(haps, haps))
    diag(hap.dist) <- 0
    stat.name <- "Fst"
  } else {
    stopifnot.aligned(g$sequences)
    hap.dist <- dist.dna(as.DNAbin(g$sequences), model = model, pairwise.deletion = pairwise.deletion)
  }
  if(!is.matrix(hap.dist)) hap.dist <- as.matrix(hap.dist)
    
  est <- phist_C(g$genotypes[, 2], g$genotypes[, 1], hap.dist)
  if(is.nan(est)) est <- NA
  
  result <- list(stat.name = stat.name, estimate = est, strata.freq = table(decode.strata(g)))
  class(result) <- c(class(result), "gtype.struct.stat")
  result
}
class(stat.phist) <- c(class(stat.phist), "gtype.struct.func")