#' @export write.fasta
#' @title write.fasta
#' @importFrom ape write.dna
#' @description Writes FASTA file of DNA sequences.
#' @param x a list of DNA sequences or a haploid \code{\link{gtypes}} object with sequences. 
#' @param file a character string specifying the filename.
#' @author Eric Archer <eric.archer@@noaa.gov>

write.fasta <- function(x, file = "sequences.fasta") {
  if(is.gtypes(x, show.warnings = FALSE)) {
    if(!is.null(x$sequences)) {
      x <- decode.sequences(x)
    } else {
      stop("'x' does not contain a list of sequences")
    }
  }
  if(!is.dna.seq(x)) stop("'x' is not a valid list of sequences")
  write.dna(x, file = file, format = "fasta", nbcol = -1, colsep = "", indent = 0, blocksep = 0)
  invisible(file)
}