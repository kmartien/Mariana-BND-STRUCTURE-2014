#' @name read.fasta
#' @export read.fasta
#' @importFrom ape read.dna
#' 
#' @title Read FASTA
#' 
#' @param file a FASTA-formatted file of sequences.
#' 
#' @return an a list of DNA sequences.
#' 
#' @author Eric Archer \email{eric.archer@@noaa.gov}
#' 
#' @seealso \code{\link{as.dna.seq}}

read.fasta <- function(file) read.dna(file, format = "fasta", as.character = TRUE, as.matrix = FALSE)