##' @name valid.iupac.codes
##' @export valid.iupac.codes
##' 
##' @title Valid IUPAC Codes
##' @description Get all possible valid IUPAC codes
##' 
##' @param bases character vectors containing nucleotides or IUPAC codes to be checked.
##' 
##' @return character vector of valid IUPAC codes.
##' 
##' @author Eric Archer \email{eric.archer@@noaa.gov}

valid.iupac.codes <- function(bases) {
  iupac.mat <- NULL # To avoid "NOTE: no visible binding for global variable 'iupac.codes'"
  data("iupac.mat", envir = environment())
  
  bases <- tolower(bases)
  base.rows <- which(rownames(iupac.mat) %in% bases)
  if(length(base.rows) == 0) stop("No valid IUPAC codes in 'bases'")
  valid.codes <- sapply(colnames(iupac.mat), function(code) all(iupac.mat[base.rows, code]))
  colnames(iupac.mat)[valid.codes]
}