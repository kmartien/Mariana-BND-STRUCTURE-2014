#' @rdname gtypes

gtypes.list <- function(gen.data, strata.vec, ... ) {
  if(!is.character(strata.vec) & !is.numeric(strata.vec) & length(strata.vec) != length(gen.data)) {
    stop("'strata.vec' must be a character or numeric vector the same length as gen.data")
  }
  haps <- label.haplotypes(gen.data)
  gen.data <- cbind(id = names(haps$haps), strata = strata.vec, haps = haps$haps)
  gtypes.default(gen.data = gen.data, id.col = 1, strata.col = 2, locus.col = 3, dna.seq = haps$hap.seqs, ...) 
}
