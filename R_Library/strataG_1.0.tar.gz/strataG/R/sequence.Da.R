#' @name sequence.Da
#' @export sequence.Da
#' @importFrom ape dist.dna
#' @importFrom ape as.DNAbin
#' 
#' @title Calculate Da
#' 
#' @param g a \code{\link{gtypes}} object.
#' @param model a character string specifying the evolutionary model to be used. 
#' @param pairwise.deletion a logical indicating whether to delete the sites with 
#' missing data in a pairwise way.
#' 
#' @details \code{model} and \code{pairwise.deletion} are passed to \code{\link[ape]{dist.dna}}.
#' 
#' @author Eric Archer \email{eric.archer@@noaa.gov}
#' 
#' @examples
#' data(dolph.strata)
#' data(dolph.haps)
#' 
#' mtdna <- gtypes(dolph.strata, id.col = 1, strata.col = 2, locus.col = 4, dna.seq = dolph.haps)
#' sequence.Da(mtdna)

sequence.Da <- function(g, model = "raw", pairwise.deletion = TRUE) {
  stopifnot.gtypes(g, "haploid")
  stopifnot.aligned(g$sequences)
  
  hap.dist <- dist.dna(as.DNAbin(g$sequences), model = model, pairwise.deletion = pairwise.deletion, as.matrix = TRUE)
  strata.gtypes <- strata.split(g, remove.sequences = FALSE)
  strata.pairs <- t(combn(names(strata.gtypes), 2))
  
  pair.diff <- function(hap1, hap2, hap.dist) {
    hap1 <- cbind(hap = hap1, strata = "strata.1")
    hap2 <- cbind(hap = hap2, strata = "strata.2")
    haps <- as.data.frame(rbind(hap1, hap2))
    hap.freq <- prop.table(table(haps$hap, haps$strata), 2)
    
    hap.pair <- expand.grid(hap1 = rownames(hap.freq), hap2 = rownames(hap.freq))
    sum(apply(hap.pair, 1, function(haps) {
      freq1 <- hap.freq[haps[1], 1]
      freq2 <- hap.freq[haps[2], 2]
      dist12 <- hap.dist[haps[1], haps[2]]
      freq1 * freq2 * dist12
    }))
  }    
  
  Da <- apply(strata.pairs, 1, function(strata) {
    haps.1 <- as.vector(strata.gtypes[[strata[1]]]$genotypes[, -1])
    haps.2 <- as.vector(strata.gtypes[[strata[2]]]$genotypes[, -1])
    haps.1[haps.1 == -1] <- NA
    haps.2[haps.2 == -1] <- NA
    between <- pair.diff(haps.1, haps.2, hap.dist)
    within.1 <- pair.diff(haps.1, haps.1, hap.dist)
    within.2 <- pair.diff(haps.2, haps.2, hap.dist)
    between - ((within.1 + within.2) / 2)
  })
  Da <- cbind(strata.pairs, Da)
  colnames(Da) <- c("strata.1", "strata.2", "Da")
  Da              
}