#' @rdname pop.diff.tests

analysis.list <- function(g, analyses = "all") {
  if(is.character(analyses)) {
    # Check that analyses specified are valid and appropriate for ploidy
    analyses <- tolower(analyses)
    haploid.analyses <- c("fst", "phist", "chi2")
    diploid.analyses <- c("fst", "fst.prime", "gst", "gst.prime", "gst.dbl.prime", "d", "chi2")
    if(analyses[1] == "all" & is.haploid(g)) analyses <- haploid.analyses
    if(analyses[1] == "all" & is.diploid(g)) analyses <- diploid.analyses
    if(is.haploid(g) & !all(analyses %in% haploid.analyses)) stop("Some 'analyses' not valid for haploid data")
    if(is.diploid(g) & !all(analyses %in% diploid.analyses)) stop("Some 'analyses' not valid for diploid data")
    
    list(phist = stat.phist, fst = stat.fst, fst.prime = stat.fst.prime, gst = stat.gst,
         gst.prime = stat.gst.prime.hedrick, gst.dbl.prime = stat.gst.dbl.prime, d = stat.d.jost, chi2 = stat.chi2
    )[analyses]
  } else if(is.list(analyses)) { # check if list of valid functions
    sapply(analyses, function(func) {
      stopifnot.gtype.struct.func(func)
      func
    }, simplify = FALSE)
  } else stop("'analyses' must be a character vector or a list of gtype population structure functions")
}