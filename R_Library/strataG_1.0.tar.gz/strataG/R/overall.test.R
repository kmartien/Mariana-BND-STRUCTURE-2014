#' @rdname pop.diff.tests
#' @importFrom parallel mclapply 
#' @importFrom swfscMisc one.arg

overall.test <- function(g, analyses = "all", nrep = 1000, keep.null = FALSE, num.cores = 1, quietly = FALSE, write.output = TRUE, ...) {  
  # check gtypes
  g <- check.gtypes(g)
  
  # check analyses
  analyses <- analysis.list(g, analyses)
  
  # check replicates
  if(!is.numeric(nrep) & length(nrep) != 1) stop("'nrep' must be a single-element numeric vector")
  if(nrep < 1) keep.null = FALSE
  
  if(!quietly) cat(format(Sys.time()), ":", attr(g, "description"), 
                   ": Running", nrep, "permutations for", length(analyses), 
                   ifelse(length(analyses) == 1, "analysis...", "analyses..."), "\n"
  )
  
  # calculate list of observed values for each population structure function
  obs <- lapply(analyses, function(f) if(one.arg(f)) f(g) else f(g, ...))
  names(obs) <- sapply(obs, function(x) x$stat.name)
  
  # calculate matrix of null distributions (rows are reps, columns are metrics)
  opt <- options(check.gtypes = FALSE, mc.cores = num.cores)
  null.dist <- if(nrep > 0) {
    null.g <- g
    do.call(rbind, mclapply(1:nrep, function(i) {
      null.g$genotypes[, "strata"] <- sample(g$genotypes[, "strata"])
      sapply(analyses, function(f) if(one.arg(f)) f(null.g)$estimate else f(null.g, ...)$estimate)
    }))
  } else rbind(sapply(analyses, function(f) NA))  

  colnames(null.dist) <- names(obs)
  options(opt)
  
  # calculate vector of p-values
  pval <-sapply(names(obs), function(stat) p.val(obs[[stat]]$estimate, null.dist[, stat]))
  names(pval) <- names(obs)
  
  null.dist <- if(keep.null) null.dist else NULL
  
  # format matrix of estimates and p-values
  result <- t(sapply(names(obs), function(stat) c(obs[[stat]]$estimate, pval[stat])))
  colnames(result) <- c("estimate", "p.val")
  
  # collect strata frequencies to named vector (assuming that frequencies from first analysis are same for all analyses)
  strata.freq <- as.numeric(obs[[1]]$strata.freq)
  names(strata.freq) <- names(obs[[1]]$strata.freq)
  
  if(!quietly) {
    sf <- cbind(strata.freq)
    colnames(sf) <- "N"
    cat("\n")
    print(sf)
    cat("\nPopulation structure results:\n")
    print(result)
    cat("\n")
  }
  
  if(write.output) {
    out.file <- gsub("[[:punct:]]", ".", paste(attr(g, "description"), "permutation test results.csv"))
    write.csv(result, out.file)
  }
  
  options(opt)
  invisible(list(strata.freq = strata.freq, result = result, null.dist = null.dist))
}
