##' @name create.consensus
##' @export create.consensus
##' 
##' @title Create Consensus Sequence
##' 
##' @param x a \code{\link{gtypes}} object with aligned sequences, or a list of aligned DNA sequences.
##' @param ignore.gaps logical. Ignore gaps at a site when creating consensus. If true, then bases with a 
##' gap are removed before consensus is calculated. If false and a gap is present, then the result is a gap.
##' 
##' @return A character vector of the consensus sequence.
##' 
##' @author Eric Archer \email{eric.archer@@noaa.gov}

create.consensus <- function(x, ignore.gaps = FALSE) { 
  if(is.gtypes(x, FALSE)) x <- decode.sequences(x$sequences)
  stopifnot.aligned(x)
  x <- do.call(rbind, lapply(x, tolower))
  apply(x, 2, iupac.code, ignore.gaps = ignore.gaps)
}