#' @name write.arlequin
#' @export write.arlequin
#' 
#' @title Write Arlequin File
#' 
#' @param g a \code{\link{gtypes}} object.
#' @param file filename for output file.
#' @param title title for data in file.
#' @param data.type type of data. Can be "DNA", "RFLP", or "MICROSAT".
#' 
#' @references Excoffier, L. G. Laval, and S. Schneider (2005) Arlequin ver. 3.0: An integrated 
#' software package for population genetics data analysis. Evolutionary Bioinformatics Online 1:47-50.\cr
#' Arlequin available at \url{http://cmpg.unibe.ch/software/arlequin3/}
#' 
#' @author Eric Archer \email{eric.archer@@noaa.gov}

write.arlequin <- function(g, file = "gtypes.prj", title = "gtypes from R", data.type = "DNA") {
  stopifnot.gtypes(g)
  
  
  if(!data.type %in% c("DNA", "RFLP", "MICROSAT")) stop("'data.type' must be DNA, RFLP, or MICROSAT.")
  if(is.diploid(g) & data.type == "DNA") stop("'data.type' cannot be DNA if 'g' is diploid.")
  if(is.haploid(g) & data.type %in% c("RFLP", "MICROSAT")) stop("'data.type' cannot be RFLP or MICROSAT if 'g' is haploid.")
  
  write("[Profile]", file = file)
  write(paste("Title = \"", title, "\"", sep = ""), file = file, append = TRUE)
  write(paste("NbSamples =", nrow(g$genotypes)), file = file, append = TRUE)
  write(paste("DataType =", data.type), file = file, append = TRUE)
  write(paste("GenotypicData =", ifelse(is.haploid(g), 0, 1)), file = file, append = TRUE)
  
  g <- decode(g)
  write("[Data]", file = file, append = TRUE)
  if(!is.null(g$sequences)) {
    write("[[HaplotypeDefinition]]", file = file, append = TRUE)
    write("HaplListName=\"Haplotypes\"", file = file, append = TRUE)
    write("HaplList={", file = file, append = TRUE)
    for(x in names(g$sequences)) write(paste(x, g$sequences[[x]]), file = file, append = TRUE)
    write("}", file = file, append = TRUE)
  }
  
  invisible(NULL)
}