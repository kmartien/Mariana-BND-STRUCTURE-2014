#' @name write.MEGA
#' @export write.MEGA
#' 
#' @title Write MEGA File
#' 
#' @param g a \code{\link{gtypes}} object.
#' @param file filename for output file.
#' @param title title for data in file.
#' @param line.width width of sequence lines.
#' 
#' @author Eric Archer

write.MEGA <- function(g, file, title = NULL, line.width = 60) {
  stopifnot.gtypes(g)
  
  if(is.null(title)) title <- attr(g, "description")
  dna.seq <- decode.sequences(g)
  
  write("#MEGA", file)
  write(paste("title:", title, sep = ""), file, append = TRUE)
  write("", file, append = TRUE)
  for(x in names(dna.seq)) {
    write(paste("#", x, sep = ""), file, append = TRUE)
    mt.seq <- dna.seq[[x]]
    for(j in seq(1, length(mt.seq), by = line.width)) {
      seq.line <- paste(mt.seq[j:(j + line.width - 1)], collapse = "")
      write(seq.line, file, append = TRUE)
    }
    write("", file, append = TRUE)
  }
}