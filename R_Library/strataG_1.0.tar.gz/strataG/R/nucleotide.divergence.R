#' @name nucleotide.divergence
#' @export nucleotide.divergence
#' @importFrom ape dist.dna
#' @importFrom ape as.DNAbin
#' 
#' @title Nucleotide Divergence
#' @description Calculate distributions of between- and within-strata nucleotide divergence 
#' (sequence distance).
#' 
#' @param g a \code{\link{gtypes}} object.
#' @param model a character string specifying the evolutionary model to be used. Passed to 
#' \code{\link[ape]{dist.dna}}. 
#' @param pairwise.deletion a logical indicating whether to delete the sites with missing data 
#' in a pairwise way. Passed to \code{\link[ape]{dist.dna}}. 
#' @param probs a numeric vector of probabilities of the pairwise distance distributions with 
#' values in \code{[0,1]}.
#' 
#' @return a list with summaries of the \code{within} and \code{between} strata pairwise distances.
#' 
#' @author Eric Archer \email{eric.archer@@noaa.gov}

nucleotide.divergence <- function(g, model = "raw", pairwise.deletion = TRUE, probs = c(0, 0.025, 0.5, 0.975, 1)) {  
  stopifnot.gtypes(g, "haploid")
  stopifnot.aligned(g$sequences)  
  
  strata.gtypes <- strata.split(g, remove.sequences = TRUE)
  
  hap.dist <- dist.dna(as.DNAbin(g$sequences), model = model, pairwise.deletion = pairwise.deletion, as.matrix = T)
  pair.dist.summary <- function(sample.pairs) {
    sample.pairs <- as.character(sample.pairs)
    pairwise.dist <- apply(sample.pairs, 1, function(haps) {
      if(any(is.na(haps))) NA else as.vector(hap.dist[haps[1], haps[2]])
    })
    dist.quant <- quantile(pairwise.dist, probs, na.rm = TRUE)
    names(dist.quant) <- paste("pct.", probs, sep = "")
    c(mean = mean(pairwise.dist, na.rm = TRUE), dist.quant)
  }
  
  within.dist <- t(sapply(strata.gtypes, function(strata) pair.dist.summary(t(combn(as.vector(strata$genotypes[, 2]), 2)))))
  
  strata.pairs <- t(combn(names(strata.gtypes), 2))
  between.dist <- t(apply(strata.pairs, 1, function(strata) {
    strata.1.haps <- as.vector(strata.gtypes[[strata[1]]]$genotypes[, 2])
    strata.2.haps <- as.vector(strata.gtypes[[strata[2]]]$genotypes[, 2])
    result <- pair.dist.summary(expand.grid(strata.1.haps, strata.2.haps))
    dA <- result["mean"] - (sum(within.dist[strata, "mean"], na.rm = TRUE) / 2)
    names(dA) <- NULL
    c(dA = dA, result)
  }))
  between.dist <- data.frame(strata.pairs, between.dist)
  colnames(between.dist)[1:2] <- c("strata.1", "strata.2")  
  
  list(within = within.dist, between = between.dist)
}