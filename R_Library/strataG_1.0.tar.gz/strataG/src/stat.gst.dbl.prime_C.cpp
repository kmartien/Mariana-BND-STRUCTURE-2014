#include <Rcpp.h>
using namespace Rcpp;
using namespace std;

// [[Rcpp::export]]
double gstDblPrime_C(NumericVector strata, NumericMatrix hets){
//function declarations
  double rowMeanC(NumericMatrix, int, int);
  double gstPrimeNei_C(NumericVector, NumericMatrix);
    
// Calculate primenei
  double primenei = gstPrimeNei_C(strata, hets);
      
// double prime calculation
  int ncol = hets.ncol();
  double Hs = rowMeanC(hets, 1, ncol);
  double est = (primenei / (1 - Hs));
    
  return(est);
}
